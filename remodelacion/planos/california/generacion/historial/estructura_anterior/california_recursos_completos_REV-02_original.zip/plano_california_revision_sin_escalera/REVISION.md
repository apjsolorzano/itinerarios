# Registro de revisiones

## REV-02

Estado: validación visual final.

Cambios:

- Retiro temporal de la escalera del estacionamiento en Nivel 1.
- Retiro del pasillo aplazado, sus líneas de cierre y columnas asociadas.
- Vehículos permanecen retirados conforme a `REV-LIMPIEZA-01`.
- Coordinación del cambio en arquitectura, acabados, electricidad e hidráulica de Nivel 1.

## REV-LIMPIEZA-01

- Limpieza general de mobiliario y equipamiento no sanitario.
- Conservación de baños completos, incluidos lavamanos e inodoros.
- Eliminación de piscina.
- Eliminación de Habitaciones I y II de Nivel 1.
- Conservación del muro de Habitación III, perímetro exterior y portón.

Procedencia:

- PDF fuente: `source/planos_casa_california_remodelacion.pdf`
- SHA-256: `e4f69232fb5bfaa51469b0355bb3247e479c4645e26ec3dfeb039616d24bf6f4`

Los cambios permanecen definidos como operaciones no destructivas dentro de los modelos JSON.
