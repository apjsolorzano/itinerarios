# Casa California - revisión sin escalera ni pasillo

Esta carpeta contiene `REV-02`, una revisión independiente y regenerable. La entrega anterior `REV-LIMPIEZA-01` permanece intacta.

## Cambios acumulados

- Se retiraron camas, cocinas, vehículos, mesas, sillas y demás mobiliario principal.
- Se conservaron los baños completos, incluidos lavamanos e inodoros.
- Se eliminó la piscina.
- En Nivel 1 se eliminaron Habitaciones I y II, conservando el portón, el perímetro y el cierre de Habitación III.
- En `REV-02` se retiraron la escalera del estacionamiento, el pasillo aplazado, sus líneas de cierre y las columnas asociadas.
- El cambio `REV-02` se coordinó en las hojas de arquitectura, acabados, electricidad e hidráulica de Nivel 1. Las hojas de Nivel 2 se conservan como referencia sin cambios adicionales.

En la hoja hidráulica se recuperan las redes azules y los símbolos naranjas después de aplicar la limpieza arquitectónica, para conservar la información de instalaciones visible.

## Archivos por hoja

- `california_model.json`: instrucciones, operaciones y entidades semánticas.
- `california_regenerated.svg`: SVG final editable.
- `california_regenerated-faithful.svg`: extracción vectorial previa a las operaciones.
- `california_preview.png`: vista de control.
- `validation/california_report.json`: procedencia, hashes y métricas de regeneración.

El juego contiene nueve hojas: portada, arquitectura de niveles 1 y 2, acabados de niveles 1 y 2, electricidad de niveles 1 y 2 e hidráulica de niveles 1 y 2.

## Regeneración

Desde esta carpeta:

```bash
python -m pip install -r california_requirements.txt
python california_build_clean_edition.py
python california_build_revision_02.py
python california_render_all.py --validate
python california_build_delivery.py
```

El regenerador verifica el SHA-256 del PDF fuente antes de producir resultados. Las operaciones de `REV-02` usan identificadores `edit.rev02-*` y se pueden ajustar o desactivar sin modificar el PDF fuente.

## Entidades para edición futura

- `REV02-STAIR-N1-REMOVE`
- `REV02-CORRIDOR-N1-REMOVE`
- `EDIT-BATHROOM-FIXTURES-KEEP`
- `EDIT-POOL-REMOVE`
- `N1-ROOMS-01-02-REMOVE`
